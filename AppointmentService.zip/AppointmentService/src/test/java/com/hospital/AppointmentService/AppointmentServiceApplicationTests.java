package com.hospital.AppointmentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
